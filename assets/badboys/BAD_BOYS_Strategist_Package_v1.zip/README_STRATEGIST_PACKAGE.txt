BAD BOYS Strategist Package v1
Includes working brand guide and visual reference assets.
Use the OG face logo geometry as the source of truth. AI-generated references are mood studies only, not final production art.
